class Colaborador {

    var idColaborador: Int = 0
    var nome: String =""
    var email : String =""
    var  senha : String =""
    var CPF : Int = 0

}