class Maquina {

   var IP : Int =0
   var idMaquina : Int = 0
   var  fkEmpresa : Int = 0
   var fkPlanoEmpresa : Int = 0
   var fkStatusMaquina: Int = 0
   var  fkTipoMaquina : Int = 0
}